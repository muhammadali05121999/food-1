<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Placed</title>
</head>
<body>
    <h1>Order Placed</h1>
    <p>Thank you for placing your order.</p>
    <p>Order ID: {{ $order->id }}</p>
    <!-- Add more order details as needed -->
</body>
</html>
